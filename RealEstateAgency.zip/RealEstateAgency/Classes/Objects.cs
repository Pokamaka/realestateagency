﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealEstateAgency
{
    public partial class Objects
    {
        public string StatusName { get; set; }
        public string AgentSName { get; set; }
        public string OwnerName { get; set; }
        public string DistrictName { get; set; }
    }
}
