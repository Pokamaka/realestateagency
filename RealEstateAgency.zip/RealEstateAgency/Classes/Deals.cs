﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealEstateAgency
{
    public partial class Deals
    {
        public string ClientFName { get; set; }
        public string AgentSName { get; set; }
        public string ObjectName { get; set; }
        public string StatusName { get; set; }
    }
}
